# Steganografi Web

Project web steganografi client-side untuk latihan.

## Fitur
- Encode pesan ke gambar dengan LSB.
- Decode pesan dari gambar.
- Password opsional dengan AES-GCM + PBKDF2.
- Preview gambar.
- Download hasil sebagai PNG.
- Tidak membutuhkan backend/server.

## Menjalankan
1. Ekstrak folder.
2. Buka `index.html` di browser modern.
3. Atau upload ketiga file (`index.html`, `style.css`, `script.js`) ke repository GitHub Pages.

## Catatan
Gunakan PNG sebagai file hasil. Jangan mengompres ulang atau mengubah gambar hasil karena perubahan piksel dapat merusak pesan tersembunyi.

Project ini dibuat untuk pembelajaran steganografi, bukan sebagai sistem keamanan tingkat tinggi.
