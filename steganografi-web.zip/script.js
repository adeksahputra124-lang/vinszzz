const $ = (s) => document.querySelector(s);

const enc = {
  image: null,
  canvas: $("#encodeCanvas"),
  ctx: $("#encodeCanvas").getContext("2d"),
  message: $("#secretMessage"),
  password: $("#encodePassword")
};
const dec = {
  image: null,
  canvas: $("#decodeCanvas"),
  ctx: $("#decodeCanvas").getContext("2d"),
  password: $("#decodePassword")
};

const MAGIC = new Uint8Array([0x53,0x54,0x47,0x31]); // STG1
const FLAG_PLAIN = 0;
const FLAG_ENCRYPTED = 1;

function setFileInfo(id, file) {
  const el = $(id);
  el.textContent = `${file.name} · ${formatBytes(file.size)}`;
  el.classList.remove("hidden");
}
function formatBytes(n) {
  if (!n) return "0 B";
  const u=["B","KB","MB","GB"], i=Math.floor(Math.log(n)/Math.log(1024));
  return `${(n/Math.pow(1024,i)).toFixed(i?1:0)} ${u[i]}`;
}
function readImage(file, canvas, wrap, label, onDone) {
  const img = new Image();
  img.onload = () => {
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    canvas.getContext("2d").drawImage(img,0,0);
    wrap.classList.remove("empty"); wrap.classList.add("has-image");
    label.textContent = `${img.naturalWidth} × ${img.naturalHeight}`;
    onDone(img);
  };
  img.onerror = () => alert("Gambar tidak dapat dibaca.");
  img.src = URL.createObjectURL(file);
}

function capacityBytes(canvas) {
  // 1 bit per RGB channel = 3 bits/pixel, minus a small header.
  return Math.floor((canvas.width * canvas.height * 3) / 8) - 16;
}
function updateCapacity() {
  if (!enc.image) { $("#capacityInfo").textContent="Pilih gambar terlebih dahulu"; return; }
  const cap = Math.max(0, capacityBytes(enc.canvas));
  $("#capacityInfo").textContent=`Kapasitas ± ${formatBytes(cap)}`;
}
$("#secretMessage").addEventListener("input", () => {
  $("#messageStatus").textContent=`${$("#secretMessage").value.length.toLocaleString("id-ID")} karakter`;
  updateCapacity();
});

function u32(n) { return new Uint8Array([(n>>>24)&255,(n>>>16)&255,(n>>>8)&255,n&255]); }
function fromU32(a,o) { return ((a[o]*2**24)>>>0)+(a[o+1]<<16)+(a[o+2]<<8)+a[o+3]; }

function bytesToBits(bytes) {
  const bits = new Uint8Array(bytes.length*8);
  for(let i=0;i<bytes.length;i++) for(let b=0;b<8;b++) bits[i*8+b]=(bytes[i]>>(7-b))&1;
  return bits;
}
function bitsToBytes(bits) {
  const bytes = new Uint8Array(Math.floor(bits.length/8));
  for(let i=0;i<bytes.length;i++){let v=0;for(let b=0;b<8;b++)v=(v<<1)|bits[i*8+b];bytes[i]=v;}
  return bytes;
}

async function deriveKey(password, salt) {
  const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({name:"PBKDF2",salt,iterations:100000,hash:"SHA-256"},base,{name:"AES-GCM",length:256},false,["encrypt","decrypt"]);
}
async function encryptMessage(text,password) {
  const salt=crypto.getRandomValues(new Uint8Array(16));
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const key=await deriveKey(password,salt);
  const ct=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv},key,new TextEncoder().encode(text)));
  const out=new Uint8Array(16+12+ct.length); out.set(salt,0); out.set(iv,16); out.set(ct,28);
  return out;
}
async function decryptMessage(data,password) {
  if(data.length<29) throw new Error("Data terenkripsi tidak lengkap.");
  const key=await deriveKey(password,data.slice(0,16));
  const plain=await crypto.subtle.decrypt({name:"AES-GCM",iv:data.slice(16,28)},key,data.slice(28));
  return new TextDecoder().decode(plain);
}

async function buildPayload(text,password) {
  let data, flag=FLAG_PLAIN;
  if(password) { data=await encryptMessage(text,password); flag=FLAG_ENCRYPTED; }
  else data=new TextEncoder().encode(text);
  const header=new Uint8Array(4+1+4);
  header.set(MAGIC,0); header[4]=flag; header.set(u32(data.length),5);
  const out=new Uint8Array(header.length+data.length); out.set(header); out.set(data,header.length);
  return out;
}

function writeLSB(canvas, bytes) {
  const ctx=canvas.getContext("2d"), img=ctx.getImageData(0,0,canvas.width,canvas.height);
  const bits=bytesToBits(bytes);
  if(bits.length>canvas.width*canvas.height*3) throw new Error("Pesan terlalu besar untuk gambar ini.");
  let bi=0;
  for(let i=0;i<img.data.length && bi<bits.length;i+=4){
    for(let c=0;c<3 && bi<bits.length;c++) img.data[i+c]=(img.data[i+c]&254)|bits[bi++];
  }
  ctx.putImageData(img,0,0);
}

function readLSB(canvas,countBytes) {
  const img=canvas.getContext("2d").getImageData(0,0,canvas.width,canvas.height);
  const bits=[];
  for(let i=0;i<img.data.length && bits.length<countBytes*8;i+=4)
    for(let c=0;c<3 && bits.length<countBytes*8;c++) bits.push(img.data[i+c]&1);
  return bitsToBytes(new Uint8Array(bits));
}

function readAllBits(canvas) {
  const img=canvas.getContext("2d").getImageData(0,0,canvas.width,canvas.height);
  const bits=[];
  for(let i=0;i<img.data.length;i+=4) for(let c=0;c<3;c++) bits.push(img.data[i+c]&1);
  return bitsToBytes(new Uint8Array(bits));
}

$("#encodeImage").addEventListener("change",e=>{
  const f=e.target.files[0]; if(!f)return;
  setFileInfo("#encodeFileInfo",f);
  readImage(f,enc.canvas,$("#encodePreviewWrap"),$("#encodePreviewLabel"),()=>{enc.image=f;$("#encodeBtn").disabled=false;updateCapacity();});
});
$("#decodeImage").addEventListener("change",e=>{
  const f=e.target.files[0]; if(!f)return;
  setFileInfo("#decodeFileInfo",f);
  readImage(f,dec.canvas,$("#decodePreviewWrap"),$("#decodePreviewLabel"),()=>{dec.image=f;$("#decodeBtn").disabled=false;});
});

$("#encodeBtn").addEventListener("click",async()=>{
  const msg=enc.message.value;
  if(!msg) return showResult("#encodeResult","Masukkan pesan terlebih dahulu.","error");
  try{
    $("#encodeBtn").disabled=true;
    const payload=await buildPayload(msg,enc.password.value);
    writeLSB(enc.canvas,payload);
    const blob=await new Promise(r=>enc.canvas.toBlob(r,"image/png"));
    const url=URL.createObjectURL(blob);
    showResult("#encodeResult",`Pesan berhasil disisipkan. Ukuran data: ${formatBytes(payload.length)}.<br><a class="download-btn" href="${url}" download="steganografi-${Date.now()}.png">⬇ Download gambar hasil</a>`,"success");
  }catch(e){showResult("#encodeResult",e.message,"error")}
  finally{$("#encodeBtn").disabled=false;}
});

$("#decodeBtn").addEventListener("click",async()=>{
  try{
    $("#decodeBtn").disabled=true;
    const first=readLSB(dec.canvas,9);
    for(let i=0;i<4;i++) if(first[i]!==MAGIC[i]) throw new Error("Tidak ditemukan pesan steganografi yang kompatibel.");
    const flag=first[4], len=fromU32(first,5);
    const max=capacityBytes(dec.canvas);
    if(len<0 || len>max) throw new Error("Header pesan tidak valid atau gambar bukan hasil project ini.");
    const all=readLSB(dec.canvas,9+len);
    const data=all.slice(9,9+len);
    let text;
    if(flag===FLAG_ENCRYPTED){
      if(!dec.password.value) throw new Error("Pesan ini menggunakan password. Masukkan password terlebih dahulu.");
      text=await decryptMessage(data,dec.password.value);
    } else if(flag===FLAG_PLAIN) {
      text=new TextDecoder().decode(data);
    } else throw new Error("Format pesan tidak dikenali.");
    showResult("#decodeResult",`Pesan ditemukan (${text.length.toLocaleString("id-ID")} karakter):<div class="secret"></div>`,"success");
    $("#decodeResult .secret").textContent=text;
  }catch(e){showResult("#decodeResult",e.message,"error")}
  finally{$("#decodeBtn").disabled=false;}
});

function showResult(id,html,type){const el=$(id);el.className=`result ${type}`;el.innerHTML=html;el.classList.remove("hidden");}

document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));
  document.querySelectorAll(".panel").forEach(x=>x.classList.remove("active-panel"));
  btn.classList.add("active"); $("#"+btn.dataset.tab).classList.add("active-panel");
}));
document.querySelectorAll("[data-toggle]").forEach(b=>b.addEventListener("click",()=>{
  const input=$("#"+b.dataset.toggle); input.type=input.type==="password"?"text":"password";
}));
["#encodeDrop","#decodeDrop"].forEach(sel=>{
  const z=$(sel);
  ["dragenter","dragover"].forEach(ev=>z.addEventListener(ev,e=>{e.preventDefault();z.classList.add("drag")}));
  ["dragleave","drop"].forEach(ev=>z.addEventListener(ev,e=>{e.preventDefault();z.classList.remove("drag")}));
  z.addEventListener("drop",e=>{
    const file=e.dataTransfer.files[0]; if(!file)return;
    const input=z.querySelector("input");
    try{const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;input.dispatchEvent(new Event("change"))}catch{}
  });
});
